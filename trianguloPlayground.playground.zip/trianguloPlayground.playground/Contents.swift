import Foundation

extension Double{
    func roundTo(places: Int)  -> Double{
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded()/divisor
    }
}

struct Point{
    let x: Double
    let y: Double
    
    func distance(from point: Point) ->Double{
    let distancia = sqrt(pow((self.x - point.x),2) + (pow((self.y - point.y),2))).roundTo(places: 2)
     print(distancia)
    return distancia
    }
}

struct Triangle{
    enum Kind{
        case equilateral
        case isosceles
        case scalene
    }
    
    let vertex1: Point
    let vertex2: Point
    let vertex3: Point
    
    var Kind : Kind{
        
            if (vertex1.distance(from: vertex2).isEqual(to: vertex2.distance(from: vertex3))) && (vertex2.distance(from: vertex3).isEqual(to: vertex1.distance(from: vertex3))){
               return Triangle.Kind.equilateral
            }else if (vertex1.distance(from: vertex2).isEqual(to: vertex2.distance(from: vertex3))) || (vertex2.distance(from: vertex3).isEqual(to: vertex3.distance(from: vertex1))){
                return Triangle.Kind.isosceles
            }else{
                return Triangle.Kind.scalene
        }
    }
    
}

let pontoA1 = Point(x: 2, y: 7)
let pontoA2 = Point(x: 2, y: 3)
let pontoA3 = Point(x: 5, y: 3)

let pontoB1 = Point(x: 2, y: 3)
let pontoB2 = Point(x: 2, y: 1)
let pontoB3 = Point(x: 4, y: 1)

let pontoC1 = Point(x: 5, y: 7)
let pontoC2 = Point(x: 10, y: 9)
let pontoC3 = Point(x: 5.768, y: 12.33)

var triangulo1 = Triangle(vertex1: pontoC1, vertex2: pontoC2, vertex3: pontoC3)


print(triangulo1.Kind)


// A(2,7), B(2,3), C(5,3) Escaleno
//A(2,3), B(2,1), C(4,1) Isosceles
//A(5,7), B(10,9), C(5.768, 12.33) Equilatero




