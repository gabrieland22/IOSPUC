enum BankOperation{
    case withdraw(value: Double)
    case deposit(from: String, value: Double)
}

protocol BankAccountProtocol{
    // Initialize
    init (number: String, holder:String)
    
    //Properties
    var balance: Double {get}
    var statement: [BankOperation] {get}
    
    //Methods
    func withdraw (value: Double) throws
    func deposit(value: Double, from account: String)
    func formattedStatement() -> String
}

public enum BankAccountError: Error{
    case insuficentFunds(currentBalance: Double)
}

class MyBank: BankAccountProtocol{
    private let number: String
    private let holder: String
    private (set) var balance: Double
    private (set) var statement : [BankOperation]
    
    required init (number: String, holder: String){
        self.number = number
        self.holder = holder
        self.balance = 0.0
        self.statement = []
    }
    
    func withdraw(value: Double) throws {
        if(value <= balance){
            balance - value
            statement.append(.withdraw(value: value))
        }else{
            throw BankAccountError.insuficentFunds(currentBalance: balance)
        }
    }
    func deposit(value: Double, from account: String) {
        balance = balance + value
        statement.append(.deposit(from: account, value: value))
    }
    func formattedStatement() -> String {
        
        var texto = """
                    OPERATION   VALUE    FROM \n
                    """
        for linha in statement{
            switch linha {
            case .deposit(let from, let value):
                      texto+="""
                             DEP         \(value)      \(from)\n
                             """
            case .withdraw(let value):
                      texto+="""
                             WDT         \(value)   \n
                             BALANCE     \(balance - value)
                             """
            }
        }
        return texto
    }
}

var banco = MyBank.init(number: "123", holder: "Gabriel")
banco.deposit(value: 5.0, from: "123")
banco.deposit(value: 5.0, from: "123")
banco.deposit(value: 5.0, from: "123")
do{
try banco.withdraw(value: 10.0)
    print("Saque Efetuado com Sucesso!")
}catch(BankAccountError.insuficentFunds(let balance)){
    print("Saldo Insuficiente valor disponível: ",balance)
}

print(banco.formattedStatement())
